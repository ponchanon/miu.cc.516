import json
import boto3
import os

# Config DynamoDB\
dynamodb = boto3.resource('dynamodb')
dynamodb_client = boto3.client('dynamodb')
table = dynamodb.Table(os.environ['TABLE'])

def set_default(obj):
    if isinstance(obj, set):
        return list(obj)
    raise TypeError

def lambda_handler(event, context):
    # Console Log Event
    print(event)
    
    # Get websiite data
    data = None;
    try:
        itemRes = table.get_item(Key={'name':os.environ['NAME']})
        print(itemRes)
        data = itemRes["Item"]
        print(data)
        msg = "Data successfully received"
    except Exception as e: 
        print(e)
        msg = "No item found"
    
    return {
        'statusCode': 200,
        'headers': {
            "Access-Control-Allow-Headers" : "application/json",
            "Access-Control-Allow-Origin": "*", # Allow from anywhere 
            "Access-Control-Allow-Methods": "GET" # Allow only GET request 
        },
        'body': json.dumps(data, default=set_default)
    }
