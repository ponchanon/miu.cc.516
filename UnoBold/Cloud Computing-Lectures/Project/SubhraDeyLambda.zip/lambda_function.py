import json
import boto3

def lambda_handler(event, context):
    
    print(event)
    
    event = json.loads(event['body'])
    print(event)
    
    subject = None;
    message = None;
    email = None;
    name = None;
    phone = None;
    
    if event['subject'] is not None:
        subject = event['subject']
        
    if event['message'] is not None:
        message = event['message']
        
    if event['email'] is not None:
        email = event['email']
        
    if event['name'] is not None:
        name = event['name']
        
    if event['phone'] is not None:
        phone = event['phone']
        
    try:
        payload = {
                    'subject' : subject,
                    'message' : message,
                    'email' : email,
                    'name' : name,
                    'phone' : phone
                }
        sns_client = boto3.client('sns')
        response = sns_client.publish (
            TargetArn = "arn:aws:sns:us-east-1:871818405897:personal",
            Message = json.dumps({'default': json.dumps(payload)}),
            MessageStructure = 'json'
        )
        msg = "Email send Successfully"
        
        try:
            sqs_client = boto3.client('sqs')
            message = sqs_client.send_message(
                QueueUrl='https://sqs.us-east-1.amazonaws.com/871818405897/personal',
                MessageBody=json.dumps(payload)
            )
            msg = "Successfully sent the email and saved to sqs"
        except Exception as e:
            print(e)
            msg = "Failed to save on sqs but email sent"
        
    except Exception as e:
        print(e)
        msg = "Failed to send the email"
    
    return {
        'statusCode': 200,
        'headers': {
            "Access-Control-Allow-Origin": "*" # Allow from anywhere 
        },
        'body': json.dumps(msg)
    }
