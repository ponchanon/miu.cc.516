import json
import boto3

# Config DynamoDB\
dynamodb = boto3.resource('dynamodb')
dynamodb_client = boto3.client('dynamodb')
table = dynamodb.Table('portfolio-email')

def lambda_handler(event, context):
    print(event)
    record = event['Records']
    print(record)
    record_json = record[0]
    print(record_json)
    body = json.loads(record_json['body'])
    print(body)
    
    try:
        table.put_item(Item=body)
        msg = "Successfully saved the item"
        
    except Exception as e: 
        print(e)
        msg = "Failed to save the item"
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
